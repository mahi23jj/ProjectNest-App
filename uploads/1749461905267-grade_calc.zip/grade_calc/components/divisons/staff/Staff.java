package components.divisons.staff;


import java.util.ArrayList;
import java.util.List;

import components.divisons.student.Student;
import components.divisons.user.User;
import components.divisons.course.Course;


// Staff Class
public class Staff extends User {
    private String courseTaught; // Store course ID for the single course taught
    private String staffid;

    public Staff(String name, String userId, String password, String courseTaught) {
        super(name, userId, password);
        this.courseTaught = courseTaught;
        this.staffid=userId;
    }

    @Override
    public void displayRole() {
        System.out.println("Role: Staff");
    }

    public String getstaffId() {
        return staffid;
    }

    public void assignGrade(Student student, Course course, String componentName, double grade) {
        if (course.getCourseId().equals(courseTaught)) { // Check if the course matches
            course.assignGrade(student, componentName, grade);
            System.out.println("Grade assigned successfully.");
        } else {
            System.out.println("You are not authorized to assign grades for this course.");
        }
    }

    public String getCourseTaught() {
        return courseTaught;
    }

    public void setCourseTaught(String courseTaught) {
        this.courseTaught = courseTaught;
    }
}

