package components.divisons.user;
public abstract class User {
    private String name;
    private String userId;
    private String password;

    public User(String name, String userId, String password) {
        this.name = name;
        this.userId = userId;
        this.password = password;
    }

    public boolean verifyPassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }

    public String getName() {
        return name;
    }

    public String getUserId() {
        return userId;
    }

    public abstract void displayRole(); // Abstraction: Method to be implemented by subclasses.
}











