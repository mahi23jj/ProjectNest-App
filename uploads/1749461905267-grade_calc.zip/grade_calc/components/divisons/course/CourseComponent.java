package components.divisons.course;

// CourseComponent Class
public class CourseComponent {
    private String name;
    private double grade;

    public CourseComponent(String name) {
        this.name = name;
        this.grade = 0.0;
    }

    public void setGrade(double grade) {
        this.grade = grade;
    }

    public double getGrade() {
        return grade;
    }

    public String getName() {
        return name;
    }
}
