package components.divisons.course;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import components.divisons.student.Student;

// Course Class
public class Course {
    private String courseName;
    private String courseId;
    private List<Student> enrolledStudents;
    private List<CourseComponent> components;
    private int creditHour;

    public Course(String courseName, String courseId, int creditHour) {
        this.courseName = courseName;
        this.courseId = courseId;
        this.creditHour = creditHour;
        this.enrolledStudents = new ArrayList<>();
        this.components = Arrays.asList(
                new CourseComponent("Mid"),
                new CourseComponent("Assessment"),
                new CourseComponent("Final")
        );
    }
    public void enrollStudent(Student student) {
        enrolledStudents.add(student);
        student.enrollInCourse(this);
    }

    public void removeStudent(Student student) {
        enrolledStudents.remove(student);
        student.dropCourse(this);
    }



    public List<Student> getEnrolledStudents() {
        return enrolledStudents;
    }

    public String getCourseName() {
        return courseName;
    }

    public String getCourseId() {
        return courseId;
    }

    public void assignGrade(Student student, String componentName, double grade) {
        for (CourseComponent component : components) {
            if (component.getName().equals(componentName)) {
                component.setGrade(grade);
                student.addGrade(component.getName(), grade);
                return;
            }
        }
        throw new IllegalArgumentException("Component name not found in the course."); // Error handling.
    }
}

