package components.divisons.student;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import components.divisons.user.User;
import components.divisons.course.Course;

// Student Class
public class Student extends User {
    private Map<String, Double> grades;
    private List<String> gradeRequests;
    private List<Course> enrolledCourses;

    public Student(String name, String userId,String password) {
        super(name, userId, password);
        this.grades = new HashMap<>();
        this.gradeRequests = new ArrayList<>();
        this.enrolledCourses = new ArrayList<>();
    }

    @Override
    public void displayRole() {
        System.out.println("Role: Student");
    }

    public void viewGrades() {
        grades.forEach((component, grade) -> {
            System.out.println(component + ": " + grade);
        });
    }

    public void requestGradeCorrection(String request) {
        gradeRequests.add(request);
    }

    public void addGrade(String componentName, double grade) {
        grades.put(componentName, grade);
    }

    public Map<String, Double> getGrades() {
        return grades;
    }

    public void enrollInCourse(Course course) {
        enrolledCourses.add(course);
    }

    public void dropCourse(Course course) {
        enrolledCourses.remove(course);
    }

    public List<Course> getEnrolledCourses() {
        return enrolledCourses;
    }
    public String getId() {
        return super.getUserId();
    }

}
