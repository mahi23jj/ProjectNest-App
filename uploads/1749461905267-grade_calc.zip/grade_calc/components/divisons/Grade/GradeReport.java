package components.divisons.Grade;

import java.util.ArrayList;
import java.util.List;

import components.divisons.student.Student;

// GradeReport Class
public class GradeReport {
    private Student student;

    public GradeReport(Student student) {
        this.student = student;
    }

    public double calculateAverage() {
        List<Double> grades = new ArrayList<>(student.getGrades().values());
        double sum = 0;
        for (double grade : grades) {
            sum += grade;
        }
        return grades.isEmpty() ? 0 : sum / grades.size();
    }

    public String determineLetterGrade(double average) {
        if (average >= 90) return "A";
        else if (average >= 80) return "B";
        else if (average >= 70) return "C";
        else if (average >= 60) return "D";
        else return "F";
    }

    public void displayReport() {
        System.out.println("Grade Report for: " + student.getName());
        student.viewGrades();
        double average = calculateAverage();
        System.out.println("Average Grade: " + average);
        System.out.println("Letter Grade: " + determineLetterGrade(average));
    }
}
