package components.Base_class;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;


import components.divisons.Grade.GradeReport;
import components.divisons.course.Course;
import components.divisons.staff.Staff;
import components.divisons.student.Student;


// GradeCalculatorSystem Class
class GradeCalculatorSystem {
    private List<Student> students;
    private List<Course> courses;
    private List<Staff> staffMembers;
    private double gradeThreshold;

    public GradeCalculatorSystem(double gradeThreshold) {
        this.students = new ArrayList<>();
        this.courses = new ArrayList<>();
        this.staffMembers = new ArrayList<>();
        this.gradeThreshold = gradeThreshold;
    }

    public void addCourse(Course course) {
        courses.add(course);
    }

    public void addStudent(Student student) {
        students.add(student);
    }

    public void addStaff(Staff staff) {
        staffMembers.add(staff);
    }

    public double calculateAverageGrade(Student student) {
        GradeReport report = new GradeReport(student);
        return report.calculateAverage();
    }

    public List<Student> listTopStudents(int topN) {
        students.sort((s1, s2) -> Double.compare(calculateAverageGrade(s2), calculateAverageGrade(s1)));
        return students.subList(0, Math.min(topN, students.size()));
    }

    public List<Student> listFailingStudents() {
        List<Student> failingStudents = new ArrayList<>();
        for (Student student : students) {
            if (calculateAverageGrade(student) < gradeThreshold) {
                failingStudents.add(student);
            }
        }
        return failingStudents;
    }

    public List<Student> getStudents() {
      return students;
    }

    public void generateGradeReport(Student student) {
        GradeReport report = new GradeReport(student);
        report.displayReport();
    }

    public Student getStudentById(String studentId) {
        for (Student student : students) {
            if (student.getId().equals(studentId)) {
                return student; // Return the matching student
            }
        }
        return null; // Return null if no student with the given ID is found
    }

    public Course getCourseById(String courseId) {
        for (Course course : courses) {
            if (course.getCourseId().equals(courseId)) {
                return course; // Return the matching student
            }
        }
        return null; // Return null if no student with the given ID is found
    }

    public Staff getStaffById(String staffId) {
        for (Staff staffs :staffMembers ) {
            if (staffs.getstaffId().equals(staffId)) {
                return staffs; // Return the matching student
            }
        }
        return null; // Return null if no student with the given ID is found
    }


    public List<Map.Entry<String, Double>> getStudentRankings() {
        Map<String, Double> rankings = new HashMap<>();
        for (Student student : students) {
            rankings.put(student.getName(), calculateAverageGrade(student));
        }
        List<Map.Entry<String, Double>> sortedRankings = new ArrayList<>(rankings.entrySet());
        sortedRankings.sort((e1, e2) -> Double.compare(e2.getValue(), e1.getValue()));
        return sortedRankings;
    }

      public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GradeCalculatorSystem system = new GradeCalculatorSystem(50.0); // Set grade threshold to 50.0

        while (true) {
            System.out.println("\n=== Grade Calculator System ===");
            System.out.println("1. Add Student");
            System.out.println("2. Add Course");
            System.out.println("3. Add Staff");
            System.out.println("4. List Top Students");
            System.out.println("5. List Failing Students");
            System.out.println("6. Generate Grade Report");
            System.out.println("7. View Student Rankings");
            System.out.println("8. add a course");
            System.out.println("9. drop a course");
            System.out.println("10. assign a grade for students");

            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1: // Add Student
                    System.out.print("Enter student name: ");
                    String studentName = scanner.nextLine();
                    System.out.print("Enter student password: ");
                    String studentpassword = scanner.nextLine();
                    System.out.print("Enter student ID: ");
                    String studentId = scanner.nextLine();
                    Student newStudent = new Student(studentName,studentId, studentpassword);
                    system.addStudent(newStudent);
                    System.out.println("Student added successfully.");
                    break;

                case 2: // Add Course
                    System.out.print("Enter course name: ");
                    String courseName = scanner.nextLine();
                    System.out.print("Enter course ID: ");
                    String courseId = scanner.nextLine();
                    System.out.print("Enter credit hours: ");
                    int creditHours = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character
                    Course newCourse = new Course(courseName, courseId, creditHours);
                    system.addCourse(newCourse);
                    System.out.println("Course added successfully.");
                    break;

                case 3: // Add Staff
                    System.out.print("Enter staff name: ");
                    String staffName = scanner.nextLine();
                    System.out.print("Enter staff ID: ");
                    String staffId = scanner.nextLine();
                    System.out.print("Enter staff password: ");
                    String staffpassword = scanner.nextLine();
                    System.out.print("Enter staff the course they tought: ");
                    String staffcourse = scanner.nextLine();
                    Staff newStaff = new Staff(staffName,staffId,staffpassword,staffcourse);
                    system.addStaff(newStaff);
                    System.out.println("Staff added successfully.");
                    break;

                case 4: // List Top Students
                    System.out.print("Enter the number of top students to list: ");
                    int topN = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character
                    List<Student> topStudents = system.listTopStudents(topN);
                    System.out.println("\nTop Students:");
                    for (Student student : topStudents) {
                        System.out.println(student.getName() + " - Average Grade: " + system.calculateAverageGrade(student));
                    }
                    break;

                case 5: // List Failing Students
                    List<Student> failingStudents = system.listFailingStudents();
                    System.out.println("\nFailing Students:");
                    for (Student student : failingStudents) {
                        System.out.println(student.getName() + " - Average Grade: " + system.calculateAverageGrade(student));
                    }
                    break;

                case 6: // Generate Grade Report
                    System.out.print("Enter student ID: ");
                    String reportStudentId = scanner.nextLine();
                    Optional<Student> studentToReport = system.getStudents().stream()
                        .filter(student -> student.getId().equals(reportStudentId))
                        .findFirst();

                    if (studentToReport.isPresent()) {
                        system.generateGradeReport(studentToReport.get());
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 7: // View Student Rankings
                    List<Map.Entry<String, Double>> rankings = system.getStudentRankings();
                    System.out.println("\nStudent Rankings:");
                    for (int i = 0; i < rankings.size(); i++) {
                        Map.Entry<String, Double> entry = rankings.get(i);
                        System.out.println((i + 1) + ". " + entry.getKey() + " - Average Grade: " + entry.getValue());
                    }
                    break;
                case 8:
                    System.out.print("Enter student ID: ");
                    String enrollStudentId = scanner.nextLine();
                    System.out.print("Enter course ID: ");
                    String enrollCourseId = scanner.nextLine();
                    Student studentToEnroll = system.getStudentById(enrollStudentId);
                    Course courseToEnroll = system.getCourseById(enrollCourseId);

                    if (studentToEnroll != null && courseToEnroll != null) {
                        courseToEnroll.enrollStudent(studentToEnroll);
                        System.out.println("you enrolled the course successfully!");
                    } else {
                        System.out.println("Invalid student ID or course ID.");
                    }
                    break;
                case 9:
                    System.out.print("Enter student ID: ");
                    String dropStudentId = scanner.nextLine();
                    System.out.print("Enter course ID: ");
                    String dropCourseId = scanner.nextLine();
                    Student studentToDrop = system.getStudentById(dropStudentId);
                    Course courseToDrop = system.getCourseById(dropCourseId);

                    if (studentToDrop != null && courseToDrop != null) {
                        courseToDrop.removeStudent(studentToDrop);
                        System.out.println("you drop the course successfully!");
                    } else {
                        System.out.println("Invalid student ID or course ID.");
                    }
                    break;
                case 10: // Assign Grade
                    System.out.print("Enter the course you thought ID: ");
                    String courseIdTaught = scanner.nextLine();
//                    Staff staff = system.getStaffById(staffIdInput); // Assume `getStaffById` is implemented
//
//
//                        String courseIdTaught = staff.getCourseTaught();
                        Course course = system.getCourseById(courseIdTaught); // Assume `getCourseById` is implemented

                        if (course != null) {
                            System.out.println("Enrolled Students:");
                            for (int i = 0; i < course.getEnrolledStudents().size(); i++) {
                                System.out.println((i + 1) + ". " + course.getEnrolledStudents().get(i).getName());
                            }
                            System.out.print("Select student number: ");
                            int studentIndex = scanner.nextInt() - 1;
                            scanner.nextLine(); // Consume newline

                            if (studentIndex >= 0 && studentIndex < course.getEnrolledStudents().size()) {
                                Student student = course.getEnrolledStudents().get(studentIndex);

                                System.out.print("Enter component name: ");
                                String componentName = scanner.nextLine();
                                System.out.print("Enter grade: ");
                                double grade = scanner.nextDouble();
                                course.assignGrade(student,componentName, grade);
                            } else {
                                System.out.println("Invalid student selection.");
                            }
                        } else {
                            System.out.println("Course not found.");
                        }

                    break;
                case 0: // Exit
                    System.out.println("Exiting the system. Goodbye!");
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


}
